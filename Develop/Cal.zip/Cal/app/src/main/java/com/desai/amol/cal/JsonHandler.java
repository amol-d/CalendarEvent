package com.desai.amol.cal;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by amdam_000 on 1/30/2016.
 */
public class JsonHandler {
    private static final String PAYOUT = "payout";
    private String jsonData;

    public JsonHandler(String jsonData) {
        this.jsonData = jsonData;
    }

    public ArrayList<CalendarEvent> getCalendarEvents() throws JSONException {
        ArrayList<CalendarEvent> events = new ArrayList<>();
        JSONObject data = new JSONObject(jsonData);
        JSONArray payouts = data.getJSONArray(PAYOUT);
        for (int i = 0; i < payouts.length(); i++) {
            JSONObject event  = payouts.getJSONObject(i);
            /*
            {
                "user_id":"1619",
                "e_m":"MF",
                "plan":"SIP",
                "client_name":"Rahul Sharma",
                "scheme_name":"Canara Robeco Emerging Equities - Regular Plan - GROWTH",
                "institution_name":"Canara Robeco Mutual Fund",
                "date_of_deduction":"10",
                "amount":"1000",
                "instrument":"Mutual Fund"}
             */
            String em = "", plan = "";
            try {
                em = event.getString("e_m");
                plan = event.getString("plan");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            events.add(new CalendarEvent(event.getString("date_of_deduction"), new UserInfo(event.getString("user_id"),
                    em,
                    plan,
                    event.getString("client_name"),
                    event.getString("scheme_name"),
                    event.getString("institution_name"),
                    event.getString("date_of_deduction"),
                    event.getString("amount"),
                    event.getString("instrument"))));
        }
        return events;
    }
}
