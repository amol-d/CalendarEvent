package com.desai.amol.cal;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.GregorianCalendar;


public class CalenderActivity extends Activity {
    public GregorianCalendar cal_month, cal_month_copy;
    private CalendarAdapter cal_adapter;
    private TextView tv_month;
    public static ArrayList<CalendarEvent> events;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calender);

        String jsonData = "{\"payout\":[\n" +
                "\n" +
                "{\"user_id\":\"1619\",\"e_m\":\"MF\",\"plan\":\"SIP\",\"client_name\":\"Rahul Sharma\",\"scheme_name\":\"Canara Robeco Emerging Equities - Regular Plan - GROWTH\",\"institution_name\":\"Canara Robeco Mutual Fund\",\"date_of_deduction\":\"10\",\"amount\":\"1000\",\"instrument\":\"Mutual Fund\"},\n" +
                "\n" +
                "{\"user_id\":\"1619\",\"institution_name\":\"Life Insurance Corporation of India\",\"scheme_name\":\"Bima Kiran\",\"client_name\":\"Rahul Sharma\",\"date_of_deduction\":\"20\",\"end_date\":\"20-02-2027\",\"amount\":\"105\",\"premium_mode\":\"Monthly\",\"instrument\":\"Life Insurance\"},\n" +
                "\n" +
                "{\"user_id\":\"1619\",\"institution_name\":\"Life Insurance Corporation of India\",\"scheme_name\":\"Jeevan Anand\",\"client_name\":\"Rahul Sharma\",\"date_of_deduction\":\"14\",\"end_date\":\"14-07-2027\",\"amount\":\"490\",\"premium_mode\":\"Monthly\",\"instrument\":\"Life Insurance\"},\n" +
                "\n" +
                "{\"user_id\":\"1619\",\"institution_name\":\"ICICI Prudential Life Insurance Co Ltd\",\"scheme_name\":\"ICICI Pru Elite Life II\",\"client_name\":\"Rahul Sharma\",\"date_of_deduction\":\"1\",\"end_date\":\"01-01-2019\",\"amount\":\"10000\",\"premium_mode\":\"Annually\",\"instrument\":\"Life Insurance\"},\n" +
                "\n" +
                "{\"user_id\":\"1619\",\"client_name\":\"Rahul Sharma\",\"scheme_name\":\"Car Loan\",\"institution_name\":\"SBI\",\"date_of_deduction\":\"9\",\"amount\":\"6836\",\"closing_date\":\"09-10-2016\",\"instrument\":\"Liabilities\"},\n" +
                "\n" +
                "{\"user_id\":\"1619\",\"client_name\":\"Rahul Sharma\",\"scheme_name\":\"Home Loan\",\"institution_name\":\"Reliance\",\"date_of_deduction\":\"1\",\"amount\":\"14943\",\"closing_date\":\"01-09-2028\",\"instrument\":\"Liabilities\"}],\n" +
                "\n" +
                "\"count\":6,\"success\":\"1\"}";
        cal_month = (GregorianCalendar) GregorianCalendar.getInstance();
        cal_month_copy = (GregorianCalendar) cal_month.clone();
        try {
            events = new JsonHandler(jsonData).getCalendarEvents();
            cal_adapter = new CalendarAdapter(this, cal_month, events);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        System.out.println(cal_adapter);


        tv_month = (TextView) findViewById(R.id.tv_month);
        tv_month.setText(android.text.format.DateFormat.format("MMMM yyyy", cal_month));

        ImageButton previous = (ImageButton) findViewById(R.id.ib_prev);

        previous.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                setPreviousMonth();
                refreshCalendar();
            }
        });

        ImageButton next = (ImageButton) findViewById(R.id.Ib_next);
        next.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                setNextMonth();
                refreshCalendar();

            }
        });

        GridView gridview = (GridView) findViewById(R.id.gv_calendar);
        gridview.setAdapter(cal_adapter);
        gridview.setOnItemClickListener(new OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {

                ((CalendarAdapter) parent.getAdapter()).setSelected(v, position);
                String selectedGridDate = CalendarAdapter.day_string
                        .get(position);

                String[] separatedTime = selectedGridDate.split("-");
                String gridvalueString = separatedTime[2].replaceFirst("^0*", "");
                int gridvalue = Integer.parseInt(gridvalueString);

                if ((gridvalue > 10) && (position < 8)) {
                    setPreviousMonth();
                    refreshCalendar();
                } else if ((gridvalue < 7) && (position > 28)) {
                    setNextMonth();
                    refreshCalendar();
                }
                ((CalendarAdapter) parent.getAdapter()).setSelected(v, position);

                ((CalendarAdapter) parent.getAdapter()).getPositionList(selectedGridDate.split("-")[2], CalenderActivity.this, position);
            }

        });


    }


    protected void setNextMonth() {
        if (cal_month.get(GregorianCalendar.MONTH) == cal_month
                .getActualMaximum(GregorianCalendar.MONTH)) {
            cal_month.set((cal_month.get(GregorianCalendar.YEAR) + 1),
                    cal_month.getActualMinimum(GregorianCalendar.MONTH), 1);
        } else {
            cal_month.set(GregorianCalendar.MONTH,
                    cal_month.get(GregorianCalendar.MONTH) + 1);
        }

    }

    protected void setPreviousMonth() {
        if (cal_month.get(GregorianCalendar.MONTH) == cal_month
                .getActualMinimum(GregorianCalendar.MONTH)) {
            cal_month.set((cal_month.get(GregorianCalendar.YEAR) - 1),
                    cal_month.getActualMaximum(GregorianCalendar.MONTH), 1);
        } else {
            cal_month.set(GregorianCalendar.MONTH,
                    cal_month.get(GregorianCalendar.MONTH) - 1);
        }

    }

    public void refreshCalendar() {
        cal_adapter.refreshDays();
        cal_adapter.notifyDataSetChanged();
        tv_month.setText(android.text.format.DateFormat.format("MMMM yyyy", cal_month));
    }

}
