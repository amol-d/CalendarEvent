package com.desai.amol.cal;

/**
 * Created by moneyfrog on 22/1/16.
 */
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class AndroidListAdapter extends ArrayAdapter<CalendarEvent>{

    private final Context context;
    private final ArrayList<CalendarEvent> values;
    private ViewHolder viewHolder;
    private final int resourceId;

    public AndroidListAdapter(Context context, int resourceId,ArrayList<CalendarEvent> values) {
        super(context, resourceId, values);
        // TODO Auto-generated constructor stub

        this.context = context;
        this.values = values;
        this.resourceId = resourceId;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(resourceId, parent, false);


            viewHolder = new ViewHolder();
            viewHolder.tv_date = (TextView) convertView.findViewById(R.id.tv_date);
            viewHolder.tv_event = (TextView) convertView.findViewById(R.id.tv_event);


            convertView.setTag(viewHolder);


        }else
        {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        CalendarEvent list_obj=values.get(position);
        viewHolder.tv_date.setText(list_obj.day_of_month);
        viewHolder.tv_event.setText(list_obj.event_details.getSchemeName());

        return convertView;
    }





    public class ViewHolder {

        TextView tv_event;
        TextView tv_date;

    }

}
