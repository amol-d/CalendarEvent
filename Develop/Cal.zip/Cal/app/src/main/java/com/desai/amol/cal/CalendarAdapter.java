package com.desai.amol.cal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;


//import com.androidfromhome.calendar.R;
//import com.androidfromhome.calendar.util.CalendarEvent;

public class CalendarAdapter extends BaseAdapter {
    private static final String TAG = CalendarAdapter.class.getSimpleName();
    private Context context;

    private java.util.Calendar month;
    public GregorianCalendar pmonth;
    /**
     * calendar instance for previous month for getting complete view
     */
    public GregorianCalendar pmonthmaxset;
    private GregorianCalendar selectedDate;
    int firstDay;
    int maxWeeknumber;
    int maxP;
    int calMaxP;
    int lastWeekDay;
    int leftDays;
    int mnthlength;
    String itemvalue, curentDateString;
    DateFormat df;

    private ArrayList<String> items;
    public static List<String> day_string;
    private View previousView;
    public ArrayList<CalendarEvent> date_collection_arr;

    public CalendarAdapter(Context context, GregorianCalendar monthCalendar, ArrayList<CalendarEvent> date_collection_arr) {
        this.date_collection_arr = date_collection_arr;
        CalendarAdapter.day_string = new ArrayList<String>();
        Locale.setDefault(Locale.US);
        month = monthCalendar;
        selectedDate = (GregorianCalendar) monthCalendar.clone();
        this.context = context;
        month.set(GregorianCalendar.DAY_OF_MONTH, 1);

        this.items = new ArrayList<String>();
        df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        curentDateString = df.format(selectedDate.getTime());
        Log.i(TAG, "Current Date = " + curentDateString);
        refreshDays();

    }

    public void setItems(ArrayList<String> items) {
        for (int i = 0; i != items.size(); i++) {
            if (items.get(i).length() == 1) {
                items.set(i, "0" + items.get(i));
            }
        }
        this.items = items;
    }

    public int getCount() {
        return day_string.size();
    }

    public Object getItem(int position) {
        return day_string.get(position);
    }

    public long getItemId(int position) {
        return 0;
    }

    // create a new view for each item referenced by the Adapter
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        TextView dayView;
        if (convertView == null) { // if it's not recycled, initialize some
            // attributes
            LayoutInflater vi = (LayoutInflater) context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = vi.inflate(R.layout.cal_item, null);
            convertView = v;
            convertView.setTag(v);
        } else {
            v = (View) convertView.getTag();
        }


        dayView = (TextView) v.findViewById(R.id.day_of_month);
        String[] separatedTime = day_string.get(position).split("-");


        String gridvalue = separatedTime[2].replaceFirst("^0*", "");
        if (day_string.get(position).equals(curentDateString)) {
            v.setBackgroundResource(R.drawable.today_background);
        } else {
            v.setBackgroundResource(R.drawable.noraml_date_background);
        }
        if ((Integer.parseInt(gridvalue) > 1) && (position < firstDay)) {
            dayView.setTextColor(Color.GRAY);
            dayView.setClickable(false);
            dayView.setFocusable(false);
        } else if ((Integer.parseInt(gridvalue) < 7) && (position > 28)) {
            dayView.setTextColor(Color.GRAY);
            dayView.setClickable(false);
            dayView.setFocusable(false);
        } else {
            // setting curent month's days in blue color.
            dayView.setTextColor(Color.WHITE);
            setEventView(v, position, dayView);
        }


        dayView.setText(gridvalue);

        // create day_of_month string for comparison
        String date = day_string.get(position);

        if (date.length() == 1) {
            date = "0" + date;
        }
        String monthStr = "" + (month.get(GregorianCalendar.MONTH) + 1);
        if (monthStr.length() == 1) {
            monthStr = "0" + monthStr;
        }

        // show icon if day_of_month is not empty and it exists in the items array
        /*ImageView iw = (ImageView) v.findViewById(R.id.date_icon);
        if (day_of_month.length() > 0 && items != null && items.contains(day_of_month)) {
            iw.setVisibility(View.VISIBLE);
        } else {
            iw.setVisibility(View.GONE);
        }
        */


        return v;
    }

    public View setSelected(View view, int pos) {
        if (previousView != null) {
        //    previousView.setBackgroundColor(Color.parseColor("#343434"));
        }

        //view.setBackgroundColor(Color.CYAN);

        int len = day_string.size();
        if (len > pos) {
            if (day_string.get(pos).equals(curentDateString)) {

            } else {

                previousView = view;

            }

        }


        return view;
    }

    public void refreshDays() {
        // clear items
        items.clear();
        day_string.clear();
        Locale.setDefault(Locale.US);
        pmonth = (GregorianCalendar) month.clone();
        // month start day. ie; sun, mon, etc
        firstDay = month.get(GregorianCalendar.DAY_OF_WEEK);
        // finding number of weeks in current month.
        maxWeeknumber = month.getActualMaximum(GregorianCalendar.WEEK_OF_MONTH);
        // allocating maximum row number for the gridview.
        mnthlength = maxWeeknumber * 7;
        maxP = getMaxP(); // previous month maximum day 31,30....
        calMaxP = maxP - (firstDay - 1);// calendar offday starting 24,25 ...
        /**
         * Calendar instance for getting a complete gridview including the three
         * month's (previous,current,next) dates.
         */
        pmonthmaxset = (GregorianCalendar) pmonth.clone();
        /**
         * setting the start day_of_month as previous month's required day_of_month.
         */
        pmonthmaxset.set(GregorianCalendar.DAY_OF_MONTH, calMaxP + 1);

        /**
         * filling calendar gridview.
         */
        for (int n = 0; n < mnthlength; n++) {

            itemvalue = df.format(pmonthmaxset.getTime());
            pmonthmaxset.add(GregorianCalendar.DATE, 1);
            Log.i(TAG, "Date : = " + itemvalue);
            day_string.add(itemvalue);
        }
        notifyDataSetChanged();
    }

    private int getMaxP() {
        int maxP;
        if (month.get(GregorianCalendar.MONTH) == month
                .getActualMinimum(GregorianCalendar.MONTH)) {
            pmonth.set((month.get(GregorianCalendar.YEAR) - 1),
                    month.getActualMaximum(GregorianCalendar.MONTH), 1);
        } else {
            pmonth.set(GregorianCalendar.MONTH,
                    month.get(GregorianCalendar.MONTH) - 1);
        }
        maxP = pmonth.getActualMaximum(GregorianCalendar.DAY_OF_MONTH);

        return maxP;
    }


    public void setEventView(View v, int pos, TextView txt) {

        int len = CalenderActivity.events.size();
        for (int i = 0; i < len; i++) {
            CalendarEvent cal_obj = CalenderActivity.events.get(i);
            String date = cal_obj.day_of_month;
            date = date.startsWith("0") ? date.replaceFirst("0", "") : date;
            //int len1 = day_string.size();
            //if (len1 > pos) {
            String calDate = day_string.get(pos).split("-")[2].startsWith("0") ? day_string.get(pos).split("-")[2].replaceFirst("0", "") : day_string.get(pos).split("-")[2];
                if (calDate.equals(date)) {
                    v.setBackgroundResource(R.drawable.event_circular_background);
                    txt.setTextColor(Color.WHITE);
                }
            //}
        }


    }


    public void getPositionList(String date, final Activity act, int position) {

        try {


            System.out.println(act);

            int len = CalenderActivity.events.size();
            System.out.println(len);
            for (int i = 0; i < len; i++) {
                CalendarEvent cal_collection = CalenderActivity.events.get(i);
                String event_date = cal_collection.day_of_month;

                String event_message = "Name : " + cal_collection.event_details.clientName + "\n" + " Scheme : " + cal_collection.event_details.getSchemeName();
                date = date.startsWith("0") ? date.replaceFirst("0", "") : date;
                if (date.equals(event_date)) {

                    Toast.makeText(context, "You have event on this day_of_month: " + event_date, Toast.LENGTH_LONG).show();
                    new AlertDialog.Builder(context)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setTitle("Date: " + event_date)
                            .setMessage("Event: " + event_message)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    refreshDays();
                                }
                            }).show();
                    break;
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }

    }

}


