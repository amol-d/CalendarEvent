package com.desai.amol.cal;

/**
 * Created by amdam_000 on 1/30/2016.
 */
public class UserInfo {
    /*
    {
    "user_id":"1619",
    "e_m":"MF",
    "plan":"SIP",
    "client_name":"Rahul Sharma",
    "scheme_name":"Canara Robeco Emerging Equities - Regular Plan - GROWTH",
    "institution_name":"Canara Robeco Mutual Fund",
    "date_of_deduction":"10",
    "amount":"1000",
    "instrument":"Mutual Fund"}
    */
    public String userID, e_m, plan, clientName, schemeName, instituteName, dateOfDeduction, amount, instrument;

    public UserInfo(String userID, String e_m, String plan, String clientName, String schemeName, String instituteName, String dateOfDeduction, String amount, String instrument) {
        this.userID = userID;
        this.e_m = e_m;
        this.plan = plan;
        this.clientName = clientName;
        this.schemeName = schemeName;
        this.instituteName = instituteName;
        this.dateOfDeduction = dateOfDeduction;
        this.amount = amount;
        this.instrument = instrument;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public String getE_m() {
        return e_m;
    }

    public void setE_m(String e_m) {
        this.e_m = e_m;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getSchemeName() {
        return schemeName;
    }

    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName;
    }

    public String getInstituteName() {
        return instituteName;
    }

    public void setInstituteName(String instituteName) {
        this.instituteName = instituteName;
    }

    public String getDateOfDeduction() {
        return dateOfDeduction;
    }

    public void setDateOfDeduction(String dateOfDeduction) {
        this.dateOfDeduction = dateOfDeduction;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getInstrument() {
        return instrument;
    }

    public void setInstrument(String instrument) {
        this.instrument = instrument;
    }
}
