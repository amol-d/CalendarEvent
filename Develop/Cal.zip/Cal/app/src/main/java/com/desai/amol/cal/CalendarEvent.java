package com.desai.amol.cal;

import java.util.ArrayList;

/**
 * Created by moneyfrog on 22/1/16.
 */

public class CalendarEvent {

    public String day_of_month = "";
    public UserInfo event_details;

    public CalendarEvent(String day_of_month, UserInfo event_details) {
        this.day_of_month = day_of_month;
        this.event_details = event_details;

    }

}



